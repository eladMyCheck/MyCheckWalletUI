/**
 Copyright © 2017 Visa. All rights reserved.
 */

#import <UIKit/UIKit.h>

//! Project version number for VisaCheckout.
FOUNDATION_EXPORT double VisaCheckoutVersionNumber;

//! Project version string for VisaCheckout.
FOUNDATION_EXPORT const unsigned char VisaCheckoutVersionString[];

#import "VisaCheckoutSDK-Swift.h"
